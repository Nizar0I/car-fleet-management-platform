
<!-- resources/views/vignettes/pdf.blade.php -->
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Vignette</title>
</head>
<body>
  <h1>Vignette Année <?php echo e($annee); ?></h1>
  <p>Immatriculation : <?php echo e($vehicule->immatriculation); ?></p>
  <p>Marque : <?php echo e($vehicule->marque); ?></p>
  <p>Modèle : <?php echo e($vehicule->modele); ?></p>
  <p>Date de génération : <?php echo e($date_generation); ?></p>
</body>
</html>


<?php /**PATH C:\xampp2\htdocs\test-auto\resources\views/vignettes/pdf.blade.php ENDPATH**/ ?>