// src/pages/ChauffeurInscriptionPage.js
import React from 'react';
import InscriptionChauffeur from '../components/InscriptionChauffeur';

function ChauffeurInscriptionPage() {
  return (
    <div>
      <InscriptionChauffeur />
    </div>
  );
}

export default ChauffeurInscriptionPage;