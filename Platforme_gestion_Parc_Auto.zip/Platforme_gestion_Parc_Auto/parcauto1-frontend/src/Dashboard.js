// import React from 'react';
// // import { Link } from 'react-router-dom';
// import './Dashboard.css'; 
// import Navbar from './Navbar';
// import AdminLayout from './AdminLayout';

// function Dashboard() {
//   return (
//     <>
//      <Navbar />
//      return (
//     <AdminLayout>
//       <h1>Bienvenue sur la Dashboard</h1>
//       <p>Choisissez une section dans le menu à gauche.</p>
//     </AdminLayout>
//   );
//     {/* <div className="dashboard-container" style={{ paddingTop: '100px' }}>
//       <h1>Tableau de Bord - Admin</h1>
//       <div className="dashboard-grid">
//         <Link to="/voitures" className="dashboard-card">🚗 Voitures</Link>
//         <Link to="/Chauffeur" className="dashboard-card">👤 Chauffeur</Link>
//         <Link to="/carburant" className="dashboard-card">⛽ Carburant</Link>
//         <Link to="/vignette" className="dashboard-card">🧾 Vignettes</Link>
//         <Link to="/maintenance" className="dashboard-card">🛠️ Maintenance</Link>
//         <Link to="/reclamations" className="dashboard-card">📨 Réclamations</Link>
//       </div>
//     </div> */}
//     </>
//   );
// }

// export default Dashboard;