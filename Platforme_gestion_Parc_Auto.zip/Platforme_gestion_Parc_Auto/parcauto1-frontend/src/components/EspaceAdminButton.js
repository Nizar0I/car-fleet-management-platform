// import React from 'react';
// import { useNavigate } from 'react-router-dom';
// import '../styles/Buttons.css';
// import { FaUserShield } from 'react-icons/fa';

// const EspaceAdminButton = () => {
//   const navigate = useNavigate();

//   const handleClick = () => {
//     navigate('/admin');
//   };

//   return (
//     <div className="btn-container">
//       <button className="btn-admin-link" onClick={handleClick}>
//         <FaUserShield style={{ marginRight: '8px' }} />
//         Espace Admin
//       </button>
//     </div>
//   );
// };

// export default EspaceAdminButton;
